def analyze_message(message):
    if "سلام" in message:
        return "سلام! چطور می‌تونم کمکت کنم؟ 🌞"
    return "پیامت دریافت شد 📨"
